import AcharyaProfile from "@/components/client/AcharyaProfile";
import Breadcrumb from "@/components/client/Breadcrumb";
import CtaTwo from "@/components/client/CtaTwo";
import FAQ from "@/components/client/FAQ";
import ImageCarousel from "@/components/client/PageSection/ImageCarousel";
import PujaChecklist from "@/components/client/PageSection/PujaChecklist";
import RelatedGrid from "@/components/client/PageSection/RelatedGrid";
import ServiceContent from "@/components/client/PageSection/ServiceContent";
import ServiceHero from "@/components/client/PageSection/ServiceHero";

export default async function ServicePage({ params }){

    const { service } = await params;

    return(
        <>
        <Breadcrumb />
        <ServiceHero />
        <ServiceContent />
        <PujaChecklist />
        <AcharyaProfile />
        <ImageCarousel />

        <FAQ />
                <RelatedGrid />
<CtaTwo />
        service page {service}
        </>
    )
}